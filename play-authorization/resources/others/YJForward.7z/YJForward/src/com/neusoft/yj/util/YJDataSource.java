package com.neusoft.yj.util;

import org.apache.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Properties;

/**
 * Desc:
 * --------
 * User: zou bo
 * Date: 12-3-13 下午2:10
 */
public class YJDataSource {
    static Logger log=Logger.getLogger(YJDataSource.class);
    
    public static final String JNDI_CONFIG_FILE="data_source.properties";
    public static final String JAVA_NAMING_FACTORY_INITIAL="java.naming.factory.initial";
    public static final String JAVA_NAMING_PROVIDER_URL="java.naming.provider.url";
    public static final String JNDI_NAME="jndiName";


    public static final String JDBC_CONFIG_FILE="jdbc.properties";
    public static final String JDBC_URL="jdbc.url";
    public static final String JDBC_DRIVER="jdbc.driver";
    public static final String JDBC_USER="user";
    public static final String JDBC_PASSWORD="password";



    private static YJDataSource ourInstance = new YJDataSource();

    // jndi setting
    private Properties jndiProperties;
    private Hashtable env;
    private Context context;
    private DataSource dataSource;
    private String dataSourceName;

    // jdbc setting
    private Properties jdbcProperties;

    private Connection connection;


    private boolean initByJndi=true;
    private boolean initByJdbc=false;

    
    public static YJDataSource getInstance() {
        return ourInstance;
    }

    private YJDataSource() {
    }

    
    public Connection getConnection() throws NamingException, SQLException, ClassNotFoundException {
        if(initByJndi){
            connection= getConnectionByJndi();
        }else if(initByJdbc){
            connection= getConnectionByJdbc();
        }else{
            log.error("Not initialized???");
        }
        return connection;
    }


    protected Connection getConnectionByJndi() throws NamingException, SQLException {
        if(context==null || dataSource==null){
            initByJndi();
        }

        if(connection==null || connection.isClosed()){
            connection=dataSource.getConnection();
        }

        return connection;
    }


    protected Connection getConnectionByJdbc() throws ClassNotFoundException, SQLException {
        if(connection==null)
            initByJdbc();
        return connection;
    }
    


    public void initByJdbc() throws ClassNotFoundException, SQLException {
        initByJdbc(jdbcProperties);
        setByJdbc();
    }

    public void initByJdbc(Properties properties) throws ClassNotFoundException, SQLException {
//        Class.forName("oracle.jdbc.driver.OracleDriver");
        this.jdbcProperties=properties;
        Class.forName(properties.getProperty(JDBC_DRIVER));

        connection= DriverManager.getConnection(
                properties.getProperty(JDBC_URL),
                properties.getProperty(JDBC_USER),
                properties.getProperty(JDBC_PASSWORD));

        setByJdbc();
    }

    public void initByJndi() throws NamingException {
        context=new InitialContext(env);
        dataSource= (DataSource) context.lookup(dataSourceName);

        setByJndi();
    }

    public void initByJndi(Properties properties) throws NamingException {
        this.jndiProperties=properties;

        env=new Hashtable();
        env.put(JAVA_NAMING_FACTORY_INITIAL, properties.getProperty(JAVA_NAMING_FACTORY_INITIAL));
        env.put(JAVA_NAMING_PROVIDER_URL, properties.getProperty(JAVA_NAMING_PROVIDER_URL));

        dataSourceName=properties.getProperty(JNDI_NAME);
        context=new InitialContext(env);
        dataSource= (DataSource) context.lookup(dataSourceName);

        setByJndi();
    }

    private void setByJndi(){
        initByJndi=true;
        initByJdbc=false;
    }

    private void setByJdbc(){
        initByJndi=false;
        initByJdbc=true;
    }
}
