package com.neusoft.yj.web;

import com.neusoft.yj.util.YJDataSource;
import org.apache.log4j.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Properties;

/**
 * Desc:
 * --------
 * User: zou bo
 * Date: 12-3-13 下午2:38
 */
public class AppInitializerServlet extends HttpServlet {

    static Logger log = Logger.getLogger(AppInitializerServlet.class);

    String message = null;
    ByteArrayOutputStream baOs = new ByteArrayOutputStream();

    public void init(ServletConfig config) throws ServletException {
        FileInputStream fis = null;
        try {
            log.info("In init ......start");
            Class.forName("weblogic.jndi.WLInitialContextFactory");


            String cfgRealPath = config.getServletContext()
                    .getRealPath("WEB-INF/conf/" + YJDataSource.JNDI_CONFIG_FILE);

            fis = new FileInputStream(cfgRealPath);
            Properties properties = new Properties();
            properties.load(fis);

            YJDataSource.getInstance().initByJndi(properties);

            message = "Initialized by JNDI successfully";
            log.info(message);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            message = "Initialized by JNDI failed";
            log.info(message);
            e.printStackTrace(new PrintStream(baOs));

            try {
                String cfgRealPath = config.getServletContext()
                        .getRealPath("WEB-INF/conf/" + YJDataSource.JDBC_CONFIG_FILE);

                fis = new FileInputStream(cfgRealPath);
                Properties properties = new Properties();
                properties.load(fis);

                YJDataSource.getInstance().initByJdbc(properties);

                message = "Initialized by JDBC successfully";
            } catch (Exception e1) {
                log.error(e.getMessage(), e);
                message = "Initialized by JDBC failed";
            }

            log.info(message);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
            log.info("In init ......end");
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.getWriter().write("<h3>" + message + "</h3>");

        if (baOs.size() > 0) {
            resp.getWriter().write("<hr/>");
            resp.getWriter().write(baOs.toString());
        }
        resp.flushBuffer();
    }

    public void destroy() {
    }
}
