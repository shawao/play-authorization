package com.neusoft.yj;

import org.apache.log4j.Logger;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Desc:
 * --------
 * User: zou bo
 * Date: 12-3-13 下午2:10
 */
public class YJForward {
    static Logger log=Logger.getLogger(YJForward.class);

    public static String loginUrl() throws UnknownHostException {
        //todo
        String localIP= InetAddress.getLocalHost().getHostAddress();
//        log.debug(localIP);
        return localIP;
    }


    public static void main(String[] args){
        try {
            log.debug(loginUrl());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
}
