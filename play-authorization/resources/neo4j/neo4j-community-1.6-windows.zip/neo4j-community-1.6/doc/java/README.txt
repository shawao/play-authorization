Neo4j Java Documentation
=======================================

Java language documentation for Neo4j.

* api - javadocs for all released libraries
  * [javadoc](api/index.html)


References
----------

* [Getting Started](http://wiki.neo4j.org/content/Getting_Started)
* [Getting Started Java With Java](http://wiki.neo4j.org/content/Getting_Started_With_Java)
