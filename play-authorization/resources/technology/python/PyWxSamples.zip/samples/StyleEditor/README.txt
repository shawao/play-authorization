I've written a style editor for the wxStyledTextCrl. It's not depedent
on Boa at all and could be useful to anyone with a wxSTC app.

The code is a bit rough, freshly written and have not had any
refactoring, but it works (only tested on windows so far), has some
comments and even a doc string here and there ;)

Please give it a go and tell me what you think.

--
Riaan Booysen
24-August-2001