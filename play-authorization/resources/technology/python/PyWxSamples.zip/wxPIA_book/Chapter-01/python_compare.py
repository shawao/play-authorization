import wx

class MyApp(wx.App):
    
    def OnInit(self):
       frame = MyFrame("Hello World", (50, 60), (450, 340))
       frame.Show()
       self.SetTopWindow(frame)
       return True
    
class MyFrame(wx.Frame):
    
    def __init__(self, title, pos, size):
        wx.Frame.__init__(self, None, -1, title, pos, size)
        # new a menu group "menuFile" and appendes two sub menus
        menuFile = wx.Menu()
        menuFile.Append(1, "&About...")
        menuFile.AppendSeparator()
        menuFile.Append(2, "E&xit")
        
        # new my own menu group for test:-)
        menuHello=wx.Menu()
        menuHello.Append(3,"&Hello")
        
        
        # new a top menubar and appendes menuFile in it
        menuBar = wx.MenuBar()
        menuBar.Append(menuFile, "&File")
        menuBar.Append(menuHello,"&SayHello")
        
        # set menubar on frame
        self.SetMenuBar(menuBar)
        self.CreateStatusBar()
        self.SetStatusText("Welcome to wxPython!")
        # bind event on method(action executor)
        self.Bind(wx.EVT_MENU, self.OnAbout, id=1)
        self.Bind(wx.EVT_MENU, self.OnQuit, id=2)
        self.Bind(wx.EVT_MENU, self.onHello, id=3)
        
    def OnQuit(self, event):
        self.Close()

    def onHello(self,event):
        wx.MessageBox("Hello, wxPython world!",wx.OK|wx.ICON_INFORMATION,self)
         
    def OnAbout(self, event):
        wx.MessageBox("This is a wxPython Hello world sample", 
                "About Hello World", wx.OK | wx.ICON_INFORMATION, self)
                
if __name__ == '__main__':
    app = MyApp(False)
    app.MainLoop()
